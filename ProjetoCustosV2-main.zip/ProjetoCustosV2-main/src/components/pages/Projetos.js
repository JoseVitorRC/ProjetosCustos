function Projetos(){
    return <h1>Projetos</h1>
}

export default Projetos