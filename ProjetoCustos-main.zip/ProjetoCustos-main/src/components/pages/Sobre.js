function Sobre(){
    return <h1>Página Sobre</h1>
}

export default Sobre